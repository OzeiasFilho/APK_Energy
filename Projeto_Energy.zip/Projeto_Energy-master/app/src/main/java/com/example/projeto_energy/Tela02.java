package com.example.projeto_energy;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Tela02 extends AppCompatActivity {

    private Button botaoIrParaTela03;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela02);

        botaoIrParaTela03 = findViewById(R.id.Calcular);

        botaoIrParaTela03.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                abrirTela03();
            }
        });
    }

    private void abrirTela03() {
        Intent intent = new Intent(Tela02.this, Tela03.class);
        startActivity(intent);
        // Adicione finish() se desejar encerrar a Tela02 ao ir para a Tela03
        // finish();
    }
}