package com.example.projeto_energy;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Tela03 extends AppCompatActivity {

    private Button botaoSalvar;
    private Button botaoSeta;

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela03);

        botaoSalvar = findViewById(R.id.salvar);
        botaoSeta = findViewById(R.id.setaa1);

        botaoSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                abrirTela04();
            }
        });

        botaoSeta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                voltarParaTela02();
            }
        });
    }

    private void abrirTela04() {
        Intent intent = new Intent(Tela03.this, Tela04.class);
        startActivity(intent);
    }

    private void voltarParaTela02() {
        Intent intent = new Intent(Tela03.this, Tela02.class);
        startActivity(intent);
        finish(); // Opcional: encerrar a Tela03 se desejar
    }
}